package com.readytalk.olive.util;

public class InvalidFileSizeException extends Exception {
	
	// Created using Eclipse's "Add generated serial version ID" refactoring.
	private static final long serialVersionUID = 1699131254533294330L;
	
	public InvalidFileSizeException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidFileSizeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidFileSizeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidFileSizeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
